title: Tensorflow安装过程
date: '2020-12-08 21:23:12'
updated: '2020-12-08 21:23:12'
tags: [神经网络]
permalink: /articles/2020/12/08/1607433792513.html
---
随着硬(you)件(xi)更新换代越来越快，在这记录安装tensorflowgpu支持的过程概要

## 安装过程

1. 确定你电脑的GPU型号，只支持绿卡。
2. 安装anaconda（可选）
3. pip安装tensoflow-gpu，这一步关系到下一步的版本号
4. 确定GPU型号所适配的CUDA版本，与cuDNN版本
   这里讲解一下，CUDA相当于显卡的并行计算专用驱动，cuDNN相当于程序需要的API
   [根据tensorflow包版本确定需要的CUDA版本和cuDNN版本](https://www.tensorflow.org/install/source_windows)
   [下载指定版本的CUDA版本包](https://developer.nvidia.com/cuda-toolkit-archive)
   [先注册登录，然后下载指定版本的cuDNN](https://developer.nvidia.com/rdp/form/cudnn-download-survey)
5. 开始安装CUDA和cuDNN
   安装CUDA时建议选自定义，驱动必选，因为它所需的驱动版本比你一般玩游戏需要的都要新。然后将VS和它的一个依赖去掉，不然会又大又慢
   如果安装好了，可以在cmd尝试输入

   ```
   nvcc -V
   ```

   cuDNN可以不叫安装，解压后可以直接覆盖到CUDA的安装目录下（bin,include,lib/x64），下一步的环境变量就比较好配置
6. 配置系统环境变量Path
   可能是直接配好的，也可能需要你添加一下，具体路径仅供参考（CUDA和cuDNN放在一起的情况下）
   `C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v10.0\bin`
   `C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v10.0\libnvvp`
   `C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v10.0\lib\x64`

## 完结撒花
