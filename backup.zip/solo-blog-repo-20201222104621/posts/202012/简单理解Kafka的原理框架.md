title: 简单理解Kafka的原理框架
date: '2020-12-03 20:26:26'
updated: '2020-12-03 20:26:26'
tags: [Kafka]
permalink: /articles/2020/12/03/1606998385997.html
---
## Kafka原理简介

### 一句话简介

Kafka是一个高吞吐量的，在分布式集群中负责消息管理的组件，如消息的分发保存接收等操作，使用java编写。

### 相关术语[1]

#### Producer

消息生产者，发布消息到Kafka的某个Topic。

#### Consumer

消息消费者，在Kafka的Topic中接收消息。

#### Consumer Group

消费者的分组，未分组的消费者属于默认组。消费者以组为单位消费Topic消息，因此一个组中订阅的Topic相同，已订阅的Topic中的每个Partition会平均分给这个组中的消费者，Consumer比Partition多时会产生空闲的Consumer。

#### Message

Kafka的消息，拥有Topic，key，Value三种内容，Topic必须是字符串而KeyValue可以是任意数据类型，但在同一Topic下必须统一。

#### Topic

逻辑上的分区概念，每一条消息和每一个生产者消费者都要有归属的Topic，在物理上不同的Topic的消息会独立保存。

#### Partition

物理上对Topic的细化分区，也是分布式系统的共有特点，每个Partition可以有多个副本，Kafka使用哈希算法将拥有相同key的消息映射到同一个Partition中，分区保存消息提高吞吐量。哈希算法的生成也叫Balance。

#### Replica

Partition的副本就是Replica，属于分布式Kafka的容灾机制，消息存储的最小物理分区的副本，拥有一个leader和若干follower，之间的数据同步由leader完成，

#### Balance

Kafka生成将同一Topic下不同Key的消息映射到某一Partition下的哈希算法，初始化时触发，当增加新的Partition、Consumer增加关闭宕机，Coordinator宕机时会产生Rebalance。Balance和Rebalance期间Kafka暂停消息收发。

#### Broker

Kafka消息集群中的服务器就是Broker。

#### Controller

Kafka 对于生产阶段的控制者，自动分配给某一个Broker，负责partition的分配，leader的选举。

#### Coordinator

Kafka对于消费阶段的协调者，自动选择一个Broker，用于给Consumer分配Partition

### 容灾机制

当broker宕机后，controller就会给受到影响的partition中读取对应partition的ISR（in-sync replica已同步的副本）列表，选一个出来做leader。[4]

### 消息可靠性

这里的策略，服务端这边的处理是follower从leader批量拉取数据来同步。但是具体的可靠性，是由生产者来决定的。
生产者生产消息的时候，通过request.required.acks参数来设置数据的可靠性。


| acks | What happen |   |
| - | - | - |
| 0 | 发过去就完事了，不关心broker是否处理成功，可能丢数据。 |   |
| 1 | 当写Leader成功后就返回,其他的replica都是通过fetcher去同步的,所以kafka是异步写，主备切换可能丢数据。 |   |
| -1 | 要等到isr里所有机器同步成功，才能返回成功，延时取决于最慢的机器。强一致，不会丢数据。 |   |

在acks=-1的时候，如果ISR少于min.insync.replicas指定的数目，那么就会返回不可用。

这里ISR列表中的机器是会变化的，根据配置replica.lag.time.max.ms，多久没同步，就会从ISR列表中剔除。以前还有根据落后多少条消息就踢出ISR，在1.0版本后就去掉了，因为这个值很难取，在高峰的时候很容易出现节点不断的进出ISR列表。

从ISA中选出leader后，follower会从把自己日志中上一个高水位后面的记录去掉，然后去和leader拿新的数据。因为新的leader选出来后，follower上面的数据，可能比新leader多，所以要截取。这里高水位的意思，对于partition和leader，就是所有ISR中都有的最新一条记录。消费者最多只能读到高水位。[4]

kafka支持3种消息投递语义
At most once：最多一次，消息可能会丢失，但不会重复
At least once：最少一次，消息不会丢失，可能会重复
Exactly once：只且一次，消息不丢失不重复，只且消费一次（0.11中实现，仅限于下游也是kafka）

在业务中，常常都是使用At least once的模型，如果需要不重复的话，往往是业务自己实现。

**At least once**

先获取数据，再进行业务处理，业务处理成功后commit offset。

1. 生产者生产消息异常，消息是否成功写入不确定，重做，可能写入重复的消息
2. 消费者处理消息，业务处理成功后，更新offset失败，消费者重启的话，会重复消费

**At most once**

先获取数据，再commit offset，最后进行业务处理。

1. 生产者生产消息异常，不管，生产下一个消息，消息就丢了
2. 消费者处理消息，先更新offset，再做业务处理，做业务处理失败，消费者重启，消息就丢了

**Exactly once**

思路是这样的，首先要保证消息不丢，再去保证不重复。所以盯着At least once的原因来搞。 首先想出来的：

1. 生产者重做导致重复写入消息——生产保证幂等性
2. 消费者重复消费——消灭重复消费，或者业务接口保证幂等性重复消费也没问题

由于业务接口是否幂等，不是Kafka能保证的，所以Kafka这里提供的exactly once是有限制的，消费者的下游也必须是Kafka。所以一下讨论的，没特殊说明，消费者的下游系统都是Kafka（注:使用Kafka connect，它对部分系统做了适配，实现了exactly once）。

#### 生产幂等性

思路是这样的，为每个producer分配一个pid，作为该producer的唯一标识。producer会为每一个<topic,partition>维护一个单调递增的seq。类似的，broker也会为每个<pid,topic,partition>记录下最新的seq。当req_seq == broker_seq+1时，broker才会接受该消息。因为：

1. 消息的seq比broker的seq大超过时，说明中间有数据还没写入，即乱序了。
2. 消息的seq不比broker的seq小，那么说明该消息已被保存。

### 安全性

Kafka的安全性体现在三点，认证机制、加密和权限管理。通过给集群主机分发签名证书，认证机制可以保证连接在Kafka集群中的机器都是合法的，若没有认证机制，任意一台得到某一台服务器地址的非法服务器都可以加入集群，这非常影响整个集群主机业务的稳定和数据的安全性。加密是消息数据以非明文方式传输，使截取到的数据难以破译。限制Client的权限也可以使Kafka更加安全。

Kafka的认证机制包括SSL协议和SASL协议，而加密机制只有SSL协议，加密范围包含Broker与Tools之间、Broker与Client（Consumer和Producer）之间、Broker之间三个方面，可以分别决定是否加密传输。

# Kafka MirrorMaker

## 一句话简介

在Kafka集群之间镜像复制传递某Topic消息的Kafka组件。对于迁移的topic而言，topic名字一样，partition数量可以不一样，消息的offset会不一样。[2]

因为MirrorMaker是Kafka的组件，其中相当多的概念都是Kafka本身的，因此相关信息都在上一模块中讨论。本章只讨论MirrorMaker所特有的。

## 配置说明[2]

--consumer.config # 消费者配置。

--producer.config # 生产者配置。

--whitelist #需要mirror的topic，支持Java正则表达式，例如'ABTestMsg|AppColdStartMsg’，或使用逗号分隔。

--blacklist #不需要拷贝的topic，支持Java正则表达式

--num.producers #producer数量，默认为1

--num.streams #consumer数量，默认为1

--queue.size #consumer和producer之间缓存的queue size，默认10000

## 相关术语

### Source Kafka Cluster

Kafka MirrorMaker监听的源集群

### Target Kafka Cluster

Kafka MirrorMaker复制的镜像消息的目标集群

## 相关特性

在Target Cluster没有对应的Topic的时候，Kafka MirrorMaker会自动为我们在Target Cluster上创建一个一模一样(Topic Name、分区数量、副本数量)一模一样的topic。如果Target Cluster存在相同的Topic则不进行创建，并且，MirrorMaker运行Source Cluster和Target Cluster的Topic的分区数量和副本数量不同。[3]

可以将MirrorMaker当作一个Consumer和Producer结合的管道，当Consumer接收到源集群相关Topic的消息时，传递给Producer，让它发送给目标集群的同名Topic。

## 可靠性、吞吐量、安全性

因为这三点某一项的改变都会影响其他两项，所以我在同一标题下讲述它们的相关性。

数据可靠性，即指数据不重复，不遗漏，可靠性的提升必然降低数据的吞吐量。数据安全性，指数据不易被截取、破译，Kafka集群不会被攻击控制，数据的加密和Kafka组件间的认证机制因为操作繁多计算量大也会影响数据的吞吐量。

## 数据可靠性

根据MirrorMaker是部署在源服务器或目标服务器的情况，产生了拉模式和推模式的概念。拉模式比推模式更有可靠性保障，因为一旦两个集群失去连接，拉模式只是暂时无法获取到数据，而推模式有可能会将数据推丢（即自己认为发送成功而没有收到响应）。因为消费组只会消费一条消息一次这个特点，将多个MirrorMaker部署在不同的Broker，而他们又归属于同一个消费者组下，可以简单的提高可靠性容错率和数据吞吐量。

## 数据吞吐量

提高数据吞吐量的方法有很多，基于Kafka的消费组特性的吞吐量优化在上一节已经提到，这其实属于增加MirrorMaker的进程数量。根据Partition的特性，可以通过增加MirrorMaker的Consumer来增加数据的接收能力，这相当于增加了线程。Consumer的数量可以是所有监听的Topic的Partition数量总和，这样在理想的分区指派策略下（如：org.apache.kafka.clients.consumer.RoundRobinAssignor）每一个Consumer负责监听一个Partition的数据。

而对于数据吞吐量的进一步提高，需要使用Monitor对Kafka的进一步监控得到数据和对实际情况的考虑，才能有更详细的策略。

## 数据安全性

然而和提升可靠性的推拉模式相反，当对于MirrorMaker使用SSL加密时， 消费者相比生产者来说性能受到的影响更大[5]。因此增加可靠性机制，如acks=all和足够的重试次数，然后再将MirrorMaker放到源集群也是可以的，这样数据从Broker到MirrorMaker的消费者是可以不需要SSL加密的，只需要生产者将消息发送给目标集群时加密就可以了。

官方文档[8]将数据加密和认证混在一起讲述，且内容简单只有配置方法，因此没有找到只针对MirrorMaker的加密方式，只有将其视作Client的数据加密方式和认证配置，详细的配置信息需要解读源码。结合各IT公司已有的Kafka集群资料[7]，加密模块可能需要特殊定制，才能实现只在外网传输中使用数据加密，而内网集群只做身份认证的方案（即只对MirrorMaker的数据传输进行加密），这种方案可以在保证安全性的同时减小加密对服务器性能的消耗而影响吞吐量与延迟度。

# 参考文献链接

[1] [https://baike.baidu.com/item/Kafka/17930165?fr=aladdin](https://baike.baidu.com/item/Kafka/17930165?fr=aladdin)

[2] [https://cloud.tencent.com/developer/article/1358933](https://cloud.tencent.com/developer/article/1358933)

[3] [https://blog.csdn.net/u010003835/article/details/86611070](https://blog.csdn.net/u010003835/article/details/86611070)

[4] [https://www.jianshu.com/p/d3e963ff8b70](https://www.jianshu.com/p/d3e963ff8b70)

[5] [http://www.dengshenyu.com/分布式系统/2017/12/23/kafka-data-mirror.html](http://www.dengshenyu.com/%E5%88%86%E5%B8%83%E5%BC%8F%E7%B3%BB%E7%BB%9F/2017/12/23/kafka-data-mirror.html)

[6] [https://blog.csdn.net/mnasd/article/details/82760508](https://blog.csdn.net/mnasd/article/details/82760508)

[7] [https://www.jianshu.com/p/ec8954ec7185](https://www.jianshu.com/p/ec8954ec7185)

[8] [http://kafka.apache.org/documentation/#security](http://kafka.apache.org/documentation/#security)
